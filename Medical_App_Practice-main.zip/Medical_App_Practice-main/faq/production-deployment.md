# FAQ: Production Deployment Guide

## ❓ How do I deploy this app to production?

Complete step-by-step guide to take your Medical App from development to production-ready deployment.

---

## 📋 Pre-Production Checklist

Before deploying to production, ensure:

- [ ] All features tested and working
- [ ] Security vulnerabilities fixed
- [ ] Database migrations tested
- [ ] Environment variables configured
- [ ] SSL certificates obtained
- [ ] Backup strategy defined
- [ ] Monitoring tools configured
- [ ] Error tracking setup
- [ ] Load testing completed
- [ ] Documentation updated

---

## 🎯 Production Deployment Roadmap

### Phase 1: Database Migration (SQLite → PostgreSQL)
### Phase 2: Backend Deployment
### Phase 3: Frontend Deployment
### Phase 4: Infrastructure Setup
### Phase 5: Monitoring & Maintenance

---

## 🗄️ Phase 1: Database Migration to PostgreSQL

### Step 1.1: Install PostgreSQL

**Ubuntu/Debian Server:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**macOS (for testing):**
```bash
brew install postgresql@15
brew services start postgresql@15
```

### Step 1.2: Create Production Database

```bash
# Access PostgreSQL
sudo -u postgres psql

# Create database and user
CREATE DATABASE medical_app_prod;
CREATE USER medical_prod_user WITH PASSWORD 'YOUR_SECURE_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON DATABASE medical_app_prod TO medical_prod_user;

# Enable necessary extensions
\c medical_app_prod
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

\q
```

### Step 1.3: Update Backend for PostgreSQL

```bash
cd backend
source venv/bin/activate

# Install PostgreSQL driver
pip install psycopg2-binary

# Update requirements.txt
pip freeze > requirements.txt
```

### Step 1.4: Configure Production Database

```bash
# Create production .env file
cat > .env.production << 'EOF'
# Database
DATABASE_URL=postgresql://medical_prod_user:YOUR_SECURE_PASSWORD@localhost:5432/medical_app_prod

# Security Keys (CHANGE THESE!)
JWT_SECRET_KEY=$(openssl rand -hex 32)
SECRET_KEY=$(openssl rand -hex 32)

# Flask Configuration
FLASK_ENV=production
FLASK_DEBUG=False

# Application
PORT=5001
HOST=0.0.0.0

# Session
SESSION_COOKIE_SECURE=True
SESSION_COOKIE_HTTPONLY=True
SESSION_COOKIE_SAMESITE=Lax
EOF
```

### Step 1.5: Migrate Data (if coming from SQLite)

```bash
# Backup SQLite data
sqlite3 medical_app.db .dump > sqlite_backup.sql

# Convert and import to PostgreSQL (requires manual adjustment)
# Or use a migration tool like pgloader

# OR start fresh with migrations
flask db upgrade
```

---

## 🚀 Phase 2: Backend Deployment

### Option 2A: Deploy to AWS EC2 (Recommended for Production)

#### Step 2A.1: Launch EC2 Instance

```bash
# AWS Console Steps:
# 1. Launch EC2 instance (Ubuntu 22.04 LTS)
# 2. Instance type: t2.small or larger (t2.micro for testing)
# 3. Configure Security Group:
#    - SSH (22) - Your IP only
#    - HTTP (80) - 0.0.0.0/0
#    - HTTPS (443) - 0.0.0.0/0
#    - Custom TCP (5001) - 0.0.0.0/0 (temporary, will remove later)
# 4. Create/Select key pair
# 5. Launch instance
```

#### Step 2A.2: Connect to EC2

```bash
# SSH into instance
chmod 400 your-key.pem
ssh -i your-key.pem ubuntu@YOUR_EC2_PUBLIC_IP
```

#### Step 2A.3: Setup Server

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y python3-pip python3-venv nginx git postgresql-client

# Install supervisor (for process management)
sudo apt install -y supervisor

# Create application user
sudo useradd -m -s /bin/bash medicalapp
sudo usermod -aG sudo medicalapp
```

#### Step 2A.4: Deploy Application

```bash
# Switch to app user
sudo su - medicalapp

# Clone repository
git clone https://github.com/yourusername/medical_app_v1.git
cd medical_app_v1/backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
pip install gunicorn

# Copy production environment file
cp .env.production .env
nano .env  # Update DATABASE_URL with actual credentials

# Run migrations
flask db upgrade

# Test the application
python run.py  # Should start successfully
# Press Ctrl+C to stop
```

#### Step 2A.5: Configure Gunicorn

```bash
# Create gunicorn config
cat > gunicorn_config.py << 'EOF'
import multiprocessing

# Server socket
bind = "127.0.0.1:5001"
backlog = 2048

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = 'sync'
worker_connections = 1000
timeout = 30
keepalive = 2

# Logging
accesslog = '/home/medicalapp/medical_app_v1/backend/logs/gunicorn_access.log'
errorlog = '/home/medicalapp/medical_app_v1/backend/logs/gunicorn_error.log'
loglevel = 'info'

# Process naming
proc_name = 'medical_app'

# Server mechanics
daemon = False
pidfile = '/home/medicalapp/medical_app_v1/backend/gunicorn.pid'
user = 'medicalapp'
group = 'medicalapp'

# SSL (if using Gunicorn for SSL, otherwise use Nginx)
# keyfile = '/path/to/key.pem'
# certfile = '/path/to/cert.pem'
EOF

# Create logs directory
mkdir -p logs
```

#### Step 2A.6: Configure Supervisor

```bash
# Exit from medicalapp user
exit

# Create supervisor config
sudo nano /etc/supervisor/conf.d/medical_app.conf
```

Add this content:
```ini
[program:medical_app]
command=/home/medicalapp/medical_app_v1/backend/venv/bin/gunicorn -c gunicorn_config.py run:app
directory=/home/medicalapp/medical_app_v1/backend
user=medicalapp
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stderr_logfile=/var/log/medical_app/error.log
stdout_logfile=/var/log/medical_app/access.log
environment=PATH="/home/medicalapp/medical_app_v1/backend/venv/bin"
```

```bash
# Create log directory
sudo mkdir -p /var/log/medical_app
sudo chown medicalapp:medicalapp /var/log/medical_app

# Update supervisor
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start medical_app

# Check status
sudo supervisorctl status medical_app
```

#### Step 2A.7: Configure Nginx

```bash
# Create Nginx config
sudo nano /etc/nginx/sites-available/medical_app
```

Add this content:
```nginx
# Rate limiting zone
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;

# Upstream backend
upstream medical_app_backend {
    server 127.0.0.1:5001 fail_timeout=30s max_fails=3;
}

# HTTP server (redirect to HTTPS)
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

# HTTPS server
server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL certificates (will be configured with Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    
    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # Logging
    access_log /var/log/nginx/medical_app_access.log;
    error_log /var/log/nginx/medical_app_error.log;
    
    # Max upload size
    client_max_body_size 10M;
    
    # API endpoints
    location /api/ {
        # Rate limiting
        limit_req zone=api_limit burst=20 nodelay;
        
        proxy_pass http://medical_app_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # WebSocket support (if needed in future)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
    
    # Health check endpoint
    location /health {
        proxy_pass http://medical_app_backend;
        access_log off;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/medical_app /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test nginx config
sudo nginx -t

# Restart nginx
sudo systemctl restart nginx
```

#### Step 2A.8: Setup SSL with Let's Encrypt

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run

# Certificate will auto-renew via cron
```

#### Step 2A.9: Configure Firewall

```bash
# Enable UFW
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable

# Remove direct access to port 5001
sudo ufw deny 5001

# Check status
sudo ufw status
```

---

### Option 2B: Deploy to Heroku (Quick & Easy)

#### Step 2B.1: Prepare Application

```bash
cd backend

# Create Procfile
cat > Procfile << 'EOF'
web: gunicorn run:app
release: flask db upgrade
EOF

# Create runtime.txt
echo "python-3.11.0" > runtime.txt

# Update requirements.txt with gunicorn
pip install gunicorn
pip freeze > requirements.txt
```

#### Step 2B.2: Deploy to Heroku

```bash
# Install Heroku CLI
brew install heroku/brew/heroku  # macOS
# OR download from https://devcenter.heroku.com/articles/heroku-cli

# Login
heroku login

# Create app
heroku create medical-app-prod

# Add PostgreSQL
heroku addons:create heroku-postgresql:mini

# Set environment variables
heroku config:set JWT_SECRET_KEY=$(openssl rand -hex 32)
heroku config:set SECRET_KEY=$(openssl rand -hex 32)
heroku config:set FLASK_ENV=production

# Deploy
git push heroku main

# Run migrations
heroku run flask db upgrade

# Open app
heroku open

# View logs
heroku logs --tail
```

**Cost:** Mini PostgreSQL = $5/month, Dyno = $7/month

---

### Option 2C: Deploy to Google Cloud Run (Serverless)

#### Step 2C.1: Create Dockerfile

```dockerfile
# backend/Dockerfile
FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt gunicorn

# Copy application
COPY . .

# Run migrations on startup (optional)
# RUN flask db upgrade

# Expose port
ENV PORT=8080
EXPOSE 8080

# Run gunicorn
CMD exec gunicorn --bind :$PORT --workers 1 --threads 8 --timeout 0 run:app
```

#### Step 2C.2: Deploy to Cloud Run

```bash
# Install gcloud CLI
# https://cloud.google.com/sdk/docs/install

# Authenticate
gcloud auth login

# Set project
gcloud config set project YOUR_PROJECT_ID

# Build and deploy
gcloud run deploy medical-app \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars JWT_SECRET_KEY=$(openssl rand -hex 32) \
  --set-env-vars DATABASE_URL=postgresql://user:pass@host/db

# Get URL
gcloud run services describe medical-app --region us-central1 --format 'value(status.url)'
```

---

## 📱 Phase 3: Frontend Deployment

### Option 3A: Flutter Web (Firebase Hosting)

#### Step 3A.1: Build Web App

```bash
cd frontend

# Update API URL to production
# Edit lib/services/api_service.dart
nano lib/services/api_service.dart
```

Change:
```dart
class ApiService {
  // Change to your production backend URL
  static const String baseUrl = 'https://your-domain.com';  // Or 'https://medical-app-prod.herokuapp.com'
  
  // Rest of the code...
}
```

```bash
# Build for web
flutter build web --release

# Output will be in build/web/
```

#### Step 3A.2: Deploy to Firebase

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Initialize Firebase in project
cd build/web
firebase init hosting

# Select:
# - Use existing project or create new one
# - Public directory: . (current directory)
# - Configure as single-page app: Yes
# - Set up automatic builds: No

# Deploy
firebase deploy --only hosting

# Get URL
# https://your-project.firebaseapp.com
```

**Cost:** Free tier (10GB storage, 360MB/day transfer)

---

### Option 3B: Flutter Web (Netlify)

```bash
cd frontend
flutter build web --release

# Install Netlify CLI
npm install -g netlify-cli

# Deploy
cd build/web
netlify deploy --prod

# Follow prompts to authorize and deploy
# Get URL: https://your-app.netlify.app
```

**Cost:** Free tier (100GB bandwidth/month)

---

### Option 3C: Flutter Web (AWS S3 + CloudFront)

```bash
cd frontend
flutter build web --release

# Install AWS CLI
# https://aws.amazon.com/cli/

# Create S3 bucket
aws s3 mb s3://medical-app-frontend

# Upload files
aws s3 sync build/web/ s3://medical-app-frontend --acl public-read

# Enable static website hosting
aws s3 website s3://medical-app-frontend --index-document index.html

# Create CloudFront distribution (via AWS Console)
# Point to S3 bucket
# Enable HTTPS with ACM certificate

# URL: https://d1234567890.cloudfront.net
```

---

### Option 3D: Mobile Apps (iOS & Android)

#### Android (Google Play Store)

```bash
cd frontend

# Generate signing key
keytool -genkey -v -keystore ~/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload

# Configure signing
# Create android/key.properties
cat > android/key.properties << 'EOF'
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=upload
storeFile=/Users/you/upload-keystore.jks
EOF

# Update android/app/build.gradle
# Add signing configuration (see deployment section in main README)

# Build release APK
flutter build apk --release

# OR build App Bundle (recommended)
flutter build appbundle --release

# Upload to Google Play Console
# https://play.google.com/console
# Release to internal testing → beta → production
```

#### iOS (App Store)

```bash
cd frontend

# Open in Xcode
open ios/Runner.xcworkspace

# Configure:
# 1. Select Runner → Signing & Capabilities
# 2. Select your team
# 3. Update Bundle Identifier (com.yourcompany.medicalapp)

# Build
flutter build ios --release

# Archive in Xcode
# Product → Archive
# Upload to App Store Connect
# Submit for review
```

---

## 🔧 Phase 4: Infrastructure Setup

### 4.1: Database Backups

**Automated PostgreSQL Backup Script:**

```bash
# Create backup script
sudo nano /usr/local/bin/backup_medical_db.sh
```

```bash
#!/bin/bash

# Configuration
DB_NAME="medical_app_prod"
DB_USER="medical_prod_user"
BACKUP_DIR="/home/medicalapp/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/medical_app_$DATE.sql"
RETENTION_DAYS=7

# Create backup directory if not exists
mkdir -p $BACKUP_DIR

# Perform backup
pg_dump -U $DB_USER $DB_NAME > $BACKUP_FILE

# Compress backup
gzip $BACKUP_FILE

# Remove old backups
find $BACKUP_DIR -name "medical_app_*.sql.gz" -mtime +$RETENTION_DAYS -delete

# Upload to S3 (optional)
# aws s3 cp $BACKUP_FILE.gz s3://your-backup-bucket/

echo "Backup completed: $BACKUP_FILE.gz"
```

```bash
# Make executable
sudo chmod +x /usr/local/bin/backup_medical_db.sh

# Add to crontab (daily at 2 AM)
sudo crontab -e
# Add: 0 2 * * * /usr/local/bin/backup_medical_db.sh
```

---

### 4.2: Monitoring with Prometheus & Grafana

**Install Prometheus:**

```bash
# Install Prometheus
sudo apt install prometheus

# Configure prometheus.yml
sudo nano /etc/prometheus/prometheus.yml
```

Add:
```yaml
scrape_configs:
  - job_name: 'medical_app'
    static_configs:
      - targets: ['localhost:5001']
```

**Install Grafana:**

```bash
sudo apt install grafana
sudo systemctl start grafana-server
sudo systemctl enable grafana-server

# Access Grafana at http://your-server:3000
# Default login: admin/admin
```

---

### 4.3: Error Tracking with Sentry

```bash
cd backend
pip install sentry-sdk[flask]
```

```python
# backend/app/__init__.py
import sentry_sdk
from sentry_sdk.integrations.flask import FlaskIntegration

def create_app():
    app = Flask(__name__)
    
    # Initialize Sentry
    if app.config.get('FLASK_ENV') == 'production':
        sentry_sdk.init(
            dsn="https://your-sentry-dsn@sentry.io/project",
            integrations=[FlaskIntegration()],
            traces_sample_rate=1.0,
            environment="production"
        )
    
    return app
```

Get free Sentry account at https://sentry.io

---

### 4.4: Logging Configuration

```python
# backend/app/__init__.py
import logging
from logging.handlers import RotatingFileHandler
import os

def create_app():
    app = Flask(__name__)
    
    if not app.debug:
        # Create logs directory
        if not os.path.exists('logs'):
            os.mkdir('logs')
        
        # File handler
        file_handler = RotatingFileHandler(
            'logs/medical_app.log',
            maxBytes=10240000,  # 10MB
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        
        app.logger.setLevel(logging.INFO)
        app.logger.info('Medical App startup')
    
    return app
```

---

### 4.5: Rate Limiting

```bash
pip install flask-limiter
```

```python
# backend/app/__init__.py
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="redis://localhost:6379"
)

# Apply to specific routes
@auth_bp.route('/login', methods=['POST'])
@limiter.limit("5 per minute")
def login():
    # Login logic
    pass
```

---

## 🔐 Phase 5: Security Hardening

### 5.1: Environment Variables

**Never commit sensitive data to Git:**

```bash
# Add to .gitignore
echo ".env" >> .gitignore
echo ".env.production" >> .gitignore
echo "*.pem" >> .gitignore
echo "*.jks" >> .gitignore
```

### 5.2: Security Headers

Already configured in Nginx, but also add in Flask:

```python
# backend/app/__init__.py
@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response
```

### 5.3: CORS Configuration

```python
# backend/app/__init__.py
from flask_cors import CORS

CORS(app, resources={
    r"/api/*": {
        "origins": ["https://your-frontend-domain.com"],  # Specific domains only
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
```

### 5.4: Input Validation

```python
# Use Flask-Marshmallow for validation
from marshmallow import Schema, fields, validate

class PatientSchema(Schema):
    email = fields.Email(required=True)
    phone = fields.Str(validate=validate.Regexp(r'^\+?1?\d{9,15}$'))
    age = fields.Int(validate=validate.Range(min=0, max=150))
```

---

## 📊 Phase 6: Performance Optimization

### 6.1: Enable Caching

```bash
# Install Redis
sudo apt install redis-server

# Install Flask-Caching
pip install flask-caching
```

```python
# backend/app/__init__.py
from flask_caching import Cache

cache = Cache(app, config={
    'CACHE_TYPE': 'redis',
    'CACHE_REDIS_HOST': 'localhost',
    'CACHE_REDIS_PORT': 6379,
    'CACHE_DEFAULT_TIMEOUT': 300
})

# Use in routes
@app.route('/api/doctors')
@cache.cached(timeout=600)
def get_doctors():
    doctors = Doctor.query.all()
    return jsonify([d.to_dict() for d in doctors])
```

### 6.2: Database Connection Pooling

Already configured in config.py, ensure it's optimized:

```python
SQLALCHEMY_ENGINE_OPTIONS = {
    'pool_size': 20,
    'max_overflow': 40,
    'pool_recycle': 3600,
    'pool_pre_ping': True,
}
```

### 6.3: Add Database Indexes

```python
# backend/app/models/user.py
class User(db.Model):
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    
class Appointment(db.Model):
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), index=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), index=True)
    appointment_date = db.Column(db.DateTime, index=True)
    status = db.Column(db.String(20), index=True)
```

---

## ✅ Post-Deployment Checklist

- [ ] **Backend accessible** via HTTPS
- [ ] **Frontend deployed** and accessible
- [ ] **Database backups** running daily
- [ ] **SSL certificates** installed and auto-renewing
- [ ] **Monitoring** setup (Sentry, logs)
- [ ] **Rate limiting** active
- [ ] **Firewall** configured
- [ ] **Error tracking** working
- [ ] **Performance** tested under load
- [ ] **Security scan** completed
- [ ] **Documentation** updated with production URLs
- [ ] **Team notified** of production deployment

---

## 🧪 Testing Production Deployment

### API Health Check

```bash
curl -I https://your-domain.com/api/health
# Should return: HTTP/2 200
```

### Load Testing

```bash
# Install Apache Bench
brew install apache-bench

# Test login endpoint
ab -n 1000 -c 10 -p login.json -T application/json https://your-domain.com/api/auth/login

# Should handle 100+ requests/second
```

---

## 📈 Monitoring Production

### Key Metrics to Track

1. **Response Time** - Target: <200ms
2. **Error Rate** - Target: <0.1%
3. **Uptime** - Target: 99.9%
4. **Database Connections** - Monitor pool usage
5. **CPU/Memory** - Keep below 80%
6. **Disk Space** - Alert at 80% full

### Setup Alerts

**Using AWS CloudWatch:**
```bash
# Create alarm for high CPU
aws cloudwatch put-metric-alarm \
  --alarm-name medical-app-high-cpu \
  --alarm-description "Alert when CPU exceeds 80%" \
  --metric-name CPUUtilization \
  --threshold 80
```

---

## 💰 Cost Estimation

### Small Scale (< 1,000 users)

| Service | Provider | Cost/Month |
|---------|----------|------------|
| Backend | Heroku Hobby | $7 |
| Database | Heroku PostgreSQL Mini | $5 |
| Frontend | Firebase Hosting | $0 (free tier) |
| SSL | Let's Encrypt | $0 |
| **Total** | | **~$12/month** |

### Medium Scale (1,000 - 10,000 users)

| Service | Provider | Cost/Month |
|---------|----------|------------|
| Backend | AWS EC2 t3.small | $15 |
| Database | AWS RDS db.t3.micro | $25 |
| Frontend | AWS S3 + CloudFront | $10 |
| SSL | AWS ACM | $0 |
| Monitoring | CloudWatch | $5 |
| **Total** | | **~$55/month** |

### Large Scale (10,000+ users)

| Service | Provider | Cost/Month |
|---------|----------|------------|
| Backend | AWS EC2 Auto-scaling (2-5 instances) | $75-200 |
| Load Balancer | AWS ALB | $20 |
| Database | AWS RDS db.t3.medium + replicas | $100-150 |
| Cache | ElastiCache Redis | $30 |
| Frontend | CloudFront + S3 | $20 |
| Monitoring | DataDog/New Relic | $50 |
| **Total** | | **~$295-470/month** |

---

## 🔄 CI/CD Pipeline (Advanced)

### GitHub Actions Deployment

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.12.12
        with:
          heroku_api_key: ${{secrets.HEROKU_API_KEY}}
          heroku_app_name: "medical-app-prod"
          heroku_email: "your-email@example.com"
          appdir: "backend"

  deploy-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.10.0'
      
      - name: Build Web
        run: |
          cd frontend
          flutter pub get
          flutter build web --release
      
      - name: Deploy to Firebase
        uses: w9jds/firebase-action@master
        with:
          args: deploy --only hosting
        env:
          FIREBASE_TOKEN: ${{secrets.FIREBASE_TOKEN}}
          PROJECT_PATH: frontend
```

---

## 📚 Additional Resources

- [AWS Deployment Best Practices](https://aws.amazon.com/architecture/well-architected/)
- [Flask Production Deployment](https://flask.palletsprojects.com/en/2.3.x/deploying/)
- [PostgreSQL Performance Tuning](https://wiki.postgresql.org/wiki/Performance_Optimization)
- [Flutter Web Deployment](https://docs.flutter.dev/deployment/web)
- [Security Best Practices OWASP](https://owasp.org/www-project-top-ten/)

---

## ✅ Summary

**To productionize your Medical App:**

1. ✅ **Migrate to PostgreSQL** for centralized, scalable database
2. ✅ **Deploy backend** to AWS EC2/Heroku with Nginx + SSL
3. ✅ **Deploy frontend** to Firebase/Netlify for web, Play Store/App Store for mobile
4. ✅ **Setup infrastructure** - backups, monitoring, logging
5. ✅ **Harden security** - HTTPS, rate limiting, validation
6. ✅ **Optimize performance** - caching, connection pooling, indexes
7. ✅ **Monitor production** - errors, performance, uptime
8. ✅ **Setup CI/CD** for automated deployments

**Recommended Start:** Heroku + Firebase (quickest, ~$12/month)

**Scalable Option:** AWS EC2 + RDS + S3/CloudFront (~$55+/month)

Your app will be production-ready, secure, and scalable! 🚀
