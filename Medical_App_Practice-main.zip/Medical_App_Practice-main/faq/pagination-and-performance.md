# FAQ: Pagination & Performance Optimization

## ❓ How can I add pagination to improve data fetch?

Pagination loads data in chunks instead of all at once, significantly improving performance and user experience.

---

## 📊 Backend Pagination Implementation

### Method 1: Offset-Based Pagination (Simple)

**Backend Route:**
```python
# app/routes/patient.py
@patient_bp.route('/appointments', methods=['GET'])
@jwt_required()
def get_appointments():
    user_id = get_jwt_identity()
    patient = Patient.query.filter_by(user_id=user_id).first()
    
    # Get pagination parameters from query string
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Validate
    if per_page > 100:
        per_page = 100  # Limit max items per page
    
    # Query with pagination
    paginated = Appointment.query.filter_by(patient_id=patient.id)\
        .order_by(Appointment.appointment_date.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    return {
        'success': True,
        'data': [apt.to_dict() for apt in paginated.items],
        'pagination': {
            'page': paginated.page,
            'per_page': paginated.per_page,
            'total_items': paginated.total,
            'total_pages': paginated.pages,
            'has_next': paginated.has_next,
            'has_prev': paginated.has_prev
        }
    }
```

**Frontend Implementation:**
```dart
// lib/services/api_service.dart
Future<Map<String, dynamic>> getAppointments({int page = 1, int perPage = 10}) async {
  final response = await get('/api/patient/appointments?page=$page&per_page=$perPage');
  return response;
}

// lib/screens/patient/appointments_screen.dart
class AppointmentsScreen extends StatefulWidget {
  @override
  _AppointmentsScreenState createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  final ApiService _apiService = ApiService();
  final ScrollController _scrollController = ScrollController();
  
  List<Map<String, dynamic>> _appointments = [];
  int _currentPage = 1;
  bool _isLoading = false;
  bool _hasMore = true;
  
  @override
  void initState() {
    super.initState();
    _loadAppointments();
    
    // Listen for scroll to bottom
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >= 
          _scrollController.position.maxScrollExtent - 200) {
        _loadMoreAppointments();
      }
    });
  }
  
  Future<void> _loadAppointments() async {
    setState(() => _isLoading = true);
    
    try {
      final response = await _apiService.getAppointments(page: 1, perPage: 10);
      
      setState(() {
        _appointments = List<Map<String, dynamic>>.from(response['data']);
        _currentPage = 1;
        _hasMore = response['pagination']['has_next'];
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      print('Error loading appointments: $e');
    }
  }
  
  Future<void> _loadMoreAppointments() async {
    if (_isLoading || !_hasMore) return;
    
    setState(() => _isLoading = true);
    
    try {
      final response = await _apiService.getAppointments(
        page: _currentPage + 1, 
        perPage: 10
      );
      
      setState(() {
        _appointments.addAll(List<Map<String, dynamic>>.from(response['data']));
        _currentPage++;
        _hasMore = response['pagination']['has_next'];
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      print('Error loading more appointments: $e');
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Appointments')),
      body: RefreshIndicator(
        onRefresh: _loadAppointments,
        child: ListView.builder(
          controller: _scrollController,
          itemCount: _appointments.length + (_hasMore ? 1 : 0),
          itemBuilder: (context, index) {
            // Show loading indicator at bottom
            if (index == _appointments.length) {
              return Center(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: CircularProgressIndicator(),
                ),
              );
            }
            
            // Show appointment card
            final appointment = _appointments[index];
            return AppointmentCard(appointment: appointment);
          },
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
```

---

### Method 2: Cursor-Based Pagination (Recommended for Large Datasets)

More efficient for large datasets, prevents issues with offset pagination.

**Backend:**
```python
@patient_bp.route('/medicines', methods=['GET'])
@jwt_required()
def get_medicines():
    user_id = get_jwt_identity()
    
    # Get cursor (ID of last item from previous page)
    cursor = request.args.get('cursor', type=int)
    limit = request.args.get('limit', 20, type=int)
    
    # Build query
    query = Medicine.query.filter_by(requires_prescription=False)
    
    # Apply cursor
    if cursor:
        query = query.filter(Medicine.id > cursor)
    
    # Fetch items + 1 to check if there are more
    medicines = query.order_by(Medicine.id).limit(limit + 1).all()
    
    # Check if there are more items
    has_more = len(medicines) > limit
    items = medicines[:limit]
    
    # Next cursor is the ID of last item
    next_cursor = items[-1].id if items else None
    
    return {
        'success': True,
        'data': [m.to_dict() for m in items],
        'pagination': {
            'next_cursor': next_cursor,
            'has_more': has_more,
            'limit': limit
        }
    }
```

**Frontend:**
```dart
class MedicinesScreen extends StatefulWidget {
  @override
  _MedicinesScreenState createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  List<Map<String, dynamic>> _medicines = [];
  int? _nextCursor;
  bool _hasMore = true;
  bool _isLoading = false;
  
  Future<void> _loadMedicines() async {
    setState(() => _isLoading = true);
    
    final response = await _apiService.getMedicines(limit: 20);
    
    setState(() {
      _medicines = List<Map<String, dynamic>>.from(response['data']);
      _nextCursor = response['pagination']['next_cursor'];
      _hasMore = response['pagination']['has_more'];
      _isLoading = false;
    });
  }
  
  Future<void> _loadMoreMedicines() async {
    if (_isLoading || !_hasMore) return;
    
    setState(() => _isLoading = true);
    
    final response = await _apiService.getMedicines(
      cursor: _nextCursor,
      limit: 20
    );
    
    setState(() {
      _medicines.addAll(List<Map<String, dynamic>>.from(response['data']));
      _nextCursor = response['pagination']['next_cursor'];
      _hasMore = response['pagination']['has_more'];
      _isLoading = false;
    });
  }
  
  // ... rest of the implementation
}
```

---

## 🚀 Other Performance Optimization Techniques

### 1. Database Query Optimization

**Add Indexes:**
```python
# app/models.py
class Appointment(db.Model):
    __tablename__ = 'appointment'
    
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), index=True)  # Add index
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), index=True)     # Add index
    appointment_date = db.Column(db.DateTime, index=True)  # Index for sorting/filtering
    status = db.Column(db.String(20), index=True)          # Index for filtering
```

**Eager Loading (Avoid N+1 Queries):**
```python
# ❌ Bad: N+1 query problem
appointments = Appointment.query.filter_by(patient_id=patient_id).all()
for apt in appointments:
    doctor_name = apt.doctor.user.email  # Separate query for each appointment!

# ✅ Good: Eager loading
appointments = Appointment.query.filter_by(patient_id=patient_id)\
    .options(db.joinedload(Appointment.doctor).joinedload(Doctor.user))\
    .all()
for apt in appointments:
    doctor_name = apt.doctor.user.email  # No additional queries!
```

**Select Only Needed Columns:**
```python
# ❌ Bad: Loads all columns
users = User.query.all()

# ✅ Good: Only load needed columns
users = db.session.query(User.id, User.email, User.role).all()
```

---

### 2. Response Caching

**Backend Caching with Flask-Caching:**
```python
# Install: pip install Flask-Caching

# app/__init__.py
from flask_caching import Cache

cache = Cache(config={
    'CACHE_TYPE': 'simple',  # Use 'redis' in production
    'CACHE_DEFAULT_TIMEOUT': 300  # 5 minutes
})

def create_app():
    app = Flask(__name__)
    cache.init_app(app)
    return app

# app/routes/patient.py
from app import cache

@patient_bp.route('/doctors', methods=['GET'])
@cache.cached(timeout=600, query_string=True)  # Cache for 10 minutes
def get_doctors():
    doctors = Doctor.query.all()
    return {
        'success': True,
        'data': [d.to_dict() for d in doctors]
    }

# Clear cache when data changes
@admin_bp.route('/doctor/<int:doctor_id>', methods=['PUT'])
@jwt_required()
def update_doctor(doctor_id):
    # Update doctor...
    db.session.commit()
    
    # Clear cache
    cache.delete('view//api/patient/doctors')
    
    return {'success': True}
```

**Frontend Caching:**
```dart
// lib/services/cache_service.dart
class CacheService {
  static final Map<String, CachedData> _cache = {};
  
  static CachedData? get(String key) {
    final cached = _cache[key];
    if (cached == null) return null;
    
    // Check if expired
    if (DateTime.now().isAfter(cached.expiresAt)) {
      _cache.remove(key);
      return null;
    }
    
    return cached;
  }
  
  static void set(String key, dynamic data, Duration ttl) {
    _cache[key] = CachedData(
      data: data,
      expiresAt: DateTime.now().add(ttl),
    );
  }
  
  static void clear() {
    _cache.clear();
  }
}

class CachedData {
  final dynamic data;
  final DateTime expiresAt;
  
  CachedData({required this.data, required this.expiresAt});
}

// lib/services/api_service.dart
Future<Map<String, dynamic>> getDoctors() async {
  final cacheKey = 'doctors_list';
  
  // Check cache first
  final cached = CacheService.get(cacheKey);
  if (cached != null) {
    return cached.data;
  }
  
  // Fetch from API
  final response = await get('/api/patient/doctors');
  
  // Cache for 10 minutes
  CacheService.set(cacheKey, response, Duration(minutes: 10));
  
  return response;
}
```

---

### 3. Request Debouncing (Search)

Prevents excessive API calls during typing:

```dart
// lib/utils/debouncer.dart
class Debouncer {
  final int milliseconds;
  Timer? _timer;
  
  Debouncer({required this.milliseconds});
  
  void run(VoidCallback action) {
    _timer?.cancel();
    _timer = Timer(Duration(milliseconds: milliseconds), action);
  }
  
  void dispose() {
    _timer?.cancel();
  }
}

// Usage in search
class MedicineSearchScreen extends StatefulWidget {
  @override
  _MedicineSearchScreenState createState() => _MedicineSearchScreenState();
}

class _MedicineSearchScreenState extends State<MedicineSearchScreen> {
  final Debouncer _debouncer = Debouncer(milliseconds: 500);
  List<Map<String, dynamic>> _searchResults = [];
  
  void _onSearchChanged(String query) {
    if (query.isEmpty) {
      setState(() => _searchResults = []);
      return;
    }
    
    // Wait 500ms after user stops typing
    _debouncer.run(() async {
      final results = await _apiService.searchMedicines(query);
      setState(() => _searchResults = results['data']);
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          TextField(
            onChanged: _onSearchChanged,
            decoration: InputDecoration(
              hintText: 'Search medicines...',
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _searchResults.length,
              itemBuilder: (context, index) {
                return MedicineCard(_searchResults[index]);
              },
            ),
          ),
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    _debouncer.dispose();
    super.dispose();
  }
}
```

---

### 4. Lazy Loading Images

```dart
// Use cached_network_image package
// pubspec.yaml
dependencies:
  cached_network_image: ^3.3.0

// Usage
import 'package:cached_network_image/cached_network_image.dart';

Widget build(BuildContext context) {
  return CachedNetworkImage(
    imageUrl: medicine['image_url'],
    placeholder: (context, url) => CircularProgressIndicator(),
    errorWidget: (context, url, error) => Icon(Icons.error),
    fadeInDuration: Duration(milliseconds: 300),
    memCacheWidth: 400,  // Resize image in memory
  );
}
```

---

### 5. Virtual Scrolling (ListView.builder)

Always use `ListView.builder` instead of `ListView`:

```dart
// ❌ Bad: Creates all widgets upfront
ListView(
  children: appointments.map((apt) => AppointmentCard(apt)).toList(),
)

// ✅ Good: Only creates visible widgets
ListView.builder(
  itemCount: appointments.length,
  itemBuilder: (context, index) {
    return AppointmentCard(appointments[index]);
  },
)
```

---

### 6. Response Compression

**Backend:**
```python
# Install: pip install flask-compress

from flask_compress import Compress

def create_app():
    app = Flask(__name__)
    Compress(app)  # Automatically compresses responses
    return app
```

**Result:** Reduces response size by 60-80% for text/JSON data.

---

### 7. Database Connection Pooling

```python
# config.py
class Config:
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,           # Max connections
        'pool_recycle': 3600,      # Recycle connections after 1 hour
        'pool_pre_ping': True,     # Check connection before using
        'max_overflow': 20         # Extra connections when pool full
    }
```

---

### 8. Async/Parallel Requests (Frontend)

```dart
// ❌ Bad: Sequential requests (slow)
final profile = await _apiService.getProfile();
final appointments = await _apiService.getAppointments();
final prescriptions = await _apiService.getPrescriptions();

// ✅ Good: Parallel requests (3x faster)
final results = await Future.wait([
  _apiService.getProfile(),
  _apiService.getAppointments(),
  _apiService.getPrescriptions(),
]);

final profile = results[0];
final appointments = results[1];
final prescriptions = results[2];
```

---

### 9. Backend Query Optimization Examples

**Filter Before Join:**
```python
# ❌ Bad: Join everything then filter
Appointment.query\
    .join(Doctor)\
    .join(Patient)\
    .filter(Appointment.status == 'confirmed')\
    .all()

# ✅ Good: Filter first, then join
Appointment.query\
    .filter(Appointment.status == 'confirmed')\
    .join(Doctor)\
    .join(Patient)\
    .all()
```

**Limit Results:**
```python
# ❌ Bad: Fetch all, then slice
appointments = Appointment.query.all()[:10]

# ✅ Good: Limit in database
appointments = Appointment.query.limit(10).all()
```

**Use Exists for Checks:**
```python
# ❌ Bad: Count all records
has_appointments = Appointment.query.filter_by(patient_id=patient_id).count() > 0

# ✅ Good: Check existence (stops at first match)
has_appointments = db.session.query(
    Appointment.query.filter_by(patient_id=patient_id).exists()
).scalar()
```

---

### 10. Frontend State Management Optimization

**Use const Constructors:**
```dart
// ✅ Prevents unnecessary rebuilds
const Text('Hello'),
const Icon(Icons.home),
const SizedBox(height: 16),
```

**Avoid Rebuilding Entire Screen:**
```dart
// ❌ Bad: Entire screen rebuilds
class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _counter = 0;
  
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ExpensiveWidget(),  // Rebuilds unnecessarily!
        Text('Counter: $_counter'),
        ElevatedButton(
          onPressed: () => setState(() => _counter++),
          child: Text('Increment'),
        ),
      ],
    );
  }
}

// ✅ Good: Only rebuild what changes
class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _counter = 0;
  
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const ExpensiveWidget(),  // Won't rebuild!
        CounterWidget(counter: _counter),  // Only this rebuilds
        ElevatedButton(
          onPressed: () => setState(() => _counter++),
          child: const Text('Increment'),
        ),
      ],
    );
  }
}
```

---

## 📊 Performance Comparison

### Without Pagination:
- **Request size:** 2MB (500 appointments)
- **Load time:** 3-5 seconds
- **Memory usage:** High
- **User experience:** Long wait, app freeze

### With Pagination (20 items/page):
- **Request size:** 80KB
- **Load time:** 0.3-0.5 seconds
- **Memory usage:** Low
- **User experience:** Fast, smooth scrolling

### With All Optimizations:
- **70-80% faster** load times
- **60-90% less** data transfer
- **50-70% less** memory usage
- **Smooth** user experience

---

## 🎯 Quick Wins Checklist

Implement these for immediate performance improvements:

- [ ] Add pagination to all list endpoints
- [ ] Use `ListView.builder` instead of `ListView`
- [ ] Add database indexes on foreign keys and frequently queried columns
- [ ] Enable response compression (Flask-Compress)
- [ ] Add debouncing to search inputs
- [ ] Cache frequently accessed data (doctor lists, medicine catalog)
- [ ] Use eager loading to prevent N+1 queries
- [ ] Optimize images (resize, compress, use cached_network_image)
- [ ] Use `const` constructors in Flutter
- [ ] Make parallel API requests where possible

---

## 🔍 Monitoring Performance

**Backend:**
```python
import time
from functools import wraps

def timing_decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.2f} seconds")
        return result
    return wrapper

@patient_bp.route('/appointments', methods=['GET'])
@timing_decorator
@jwt_required()
def get_appointments():
    # Your code...
```

**Frontend:**
```dart
// Use Flutter DevTools Performance tab
// Or add timing logs:
final stopwatch = Stopwatch()..start();
final data = await _apiService.getAppointments();
stopwatch.stop();
print('API call took: ${stopwatch.elapsedMilliseconds}ms');
```

---

## 📚 Additional Resources

- Flask-SQLAlchemy Pagination: https://flask-sqlalchemy.palletsprojects.com/en/3.0.x/pagination/
- Flutter Performance Best Practices: https://docs.flutter.dev/perf/best-practices
- Database Indexing Guide: https://use-the-index-luke.com/
- HTTP Caching: https://developer.mozilla.org/en-US/docs/Web/HTTP/Caching

---

**Summary:** Pagination is the #1 performance improvement, but combining it with caching, indexing, debouncing, and frontend optimizations will give you the best results!
