# FAQ: Centralized Database Setup

## ❓ How can I store all the details about database and tables into a centralized database rather than individual computer?

**Short Answer:** Replace SQLite with a centralized database server like PostgreSQL, MySQL, or MongoDB, and configure all application instances to connect to the same database server.

---

## 🎯 Why Use a Centralized Database?

### Current Setup (SQLite)
```
┌─────────────┐
│ Computer 1  │
│   SQLite    │  ← Local file (medical_app.db)
│   (Isolated)│
└─────────────┘

┌─────────────┐
│ Computer 2  │
│   SQLite    │  ← Different local file
│   (Isolated)│
└─────────────┘

❌ Data NOT shared between computers
❌ No concurrent access from multiple users
❌ Manual data synchronization required
```

### Centralized Database Setup
```
┌─────────────┐         ┌─────────────┐
│ Computer 1  │────────▶│             │
│  App Server │         │             │
└─────────────┘         │             │
                        │ PostgreSQL  │
┌─────────────┐         │   Server    │
│ Computer 2  │────────▶│             │
│  App Server │         │ (Centralized)│
└─────────────┘         │             │
                        │             │
┌─────────────┐         │             │
│ Computer 3  │────────▶│             │
│  App Server │         │             │
└─────────────┘         └─────────────┘

✅ All data in one place
✅ Multiple users can access simultaneously
✅ Automatic data synchronization
✅ Better backup and recovery
```

---

## 🚀 Option 1: PostgreSQL (Recommended)

### Step 1: Install PostgreSQL

#### On macOS:
```bash
# Install PostgreSQL
brew install postgresql@15

# Start PostgreSQL service
brew services start postgresql@15

# Verify installation
psql --version
```

#### On Ubuntu/Linux:
```bash
# Install PostgreSQL
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Verify installation
psql --version
```

#### On Windows:
```bash
# Download installer from https://www.postgresql.org/download/windows/
# Run the installer and follow the setup wizard
# Default port: 5432
```

---

### Step 2: Create Database and User

```bash
# Access PostgreSQL command line (macOS/Linux)
sudo -u postgres psql

# OR on macOS (if installed via Homebrew)
psql postgres
```

```sql
-- Create database
CREATE DATABASE medical_app;

-- Create user with password
CREATE USER medical_app_user WITH PASSWORD 'your_secure_password_here';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE medical_app TO medical_app_user;

-- Exit
\q
```

---

### Step 3: Update Backend Configuration

#### Install PostgreSQL Driver:
```bash
cd backend
source venv/bin/activate

# Install psycopg2 (PostgreSQL adapter for Python)
pip install psycopg2-binary

# Update requirements.txt
pip freeze > requirements.txt
```

#### Update `.env` File:
```bash
# backend/.env

# Replace SQLite connection with PostgreSQL
DATABASE_URL=postgresql://medical_app_user:your_secure_password_here@localhost:5432/medical_app

JWT_SECRET_KEY=your_jwt_secret_key
SECRET_KEY=your_secret_key
FLASK_APP=run.py
FLASK_ENV=development
```

#### Update `config.py`:
```python
# backend/app/config.py
import os

class Config:
    # Database configuration
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///medical_app.db')
    
    # Fix for Heroku postgres URL (postgres:// → postgresql://)
    if SQLALCHEMY_DATABASE_URI and SQLALCHEMY_DATABASE_URI.startswith("postgres://"):
        SQLALCHEMY_DATABASE_URI = SQLALCHEMY_DATABASE_URI.replace("postgres://", "postgresql://", 1)
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Connection pooling for better performance
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,           # Number of connections to maintain
        'max_overflow': 20,        # Additional connections when pool is full
        'pool_recycle': 3600,      # Recycle connections after 1 hour
        'pool_pre_ping': True,     # Verify connections before using
    }
    
    # JWT configuration
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY')
    JWT_ACCESS_TOKEN_EXPIRES = 86400  # 24 hours
    
    # Other settings
    SECRET_KEY = os.getenv('SECRET_KEY')
```

---

### Step 4: Migrate Database

```bash
cd backend
source venv/bin/activate

# Remove old SQLite migrations (if any)
rm -rf migrations/

# Initialize new migrations for PostgreSQL
flask db init

# Create migration
flask db migrate -m "Initial PostgreSQL migration"

# Apply migration
flask db upgrade
```

---

### Step 5: Run Backend

```bash
# Start the backend server
python run.py
```

Your app now uses PostgreSQL! All data is stored centrally.

---

## 🌐 Option 2: Remote PostgreSQL Server

For accessing the database from multiple computers on a network:

### Step 1: Configure PostgreSQL to Accept Remote Connections

#### Edit `postgresql.conf`:
```bash
# Find config file location
sudo -u postgres psql -c "SHOW config_file;"

# Edit the file
sudo nano /etc/postgresql/15/main/postgresql.conf
```

Find and update:
```conf
# Change from:
listen_addresses = 'localhost'

# To (allow all IP addresses):
listen_addresses = '*'

# OR specify specific IP:
listen_addresses = '192.168.1.100,localhost'
```

#### Edit `pg_hba.conf`:
```bash
sudo nano /etc/postgresql/15/main/pg_hba.conf
```

Add this line to allow connections from your network:
```conf
# TYPE  DATABASE        USER                ADDRESS                 METHOD
host    medical_app     medical_app_user    192.168.1.0/24         md5
```

#### Restart PostgreSQL:
```bash
sudo systemctl restart postgresql
```

---

### Step 2: Update Backend `.env` on Each Computer

**On Computer 1:**
```bash
# backend/.env
DATABASE_URL=postgresql://medical_app_user:your_password@192.168.1.100:5432/medical_app
```

**On Computer 2:**
```bash
# backend/.env
DATABASE_URL=postgresql://medical_app_user:your_password@192.168.1.100:5432/medical_app
```

**Note:** Replace `192.168.1.100` with your PostgreSQL server's IP address.

---

### Step 3: Find Your Server IP Address

```bash
# macOS/Linux
ifconfig | grep "inet "

# Windows
ipconfig

# Look for IPv4 address (e.g., 192.168.1.100)
```

---

### Step 4: Test Connection

From another computer:
```bash
# Test PostgreSQL connection
psql -h 192.168.1.100 -U medical_app_user -d medical_app

# If successful, you'll see PostgreSQL prompt
medical_app=#
```

---

## ☁️ Option 3: Cloud-Hosted Database (Production)

For production or internet-accessible applications:

### 3.1 Amazon RDS (AWS)

```bash
# Create RDS PostgreSQL instance on AWS console
# Get connection details:
# Endpoint: medical-app.abc123.us-east-1.rds.amazonaws.com
# Port: 5432
# Database: medical_app
# Username: admin
# Password: your_password

# Update backend/.env
DATABASE_URL=postgresql://admin:your_password@medical-app.abc123.us-east-1.rds.amazonaws.com:5432/medical_app
```

**Advantages:**
- ✅ Fully managed (automatic backups, updates)
- ✅ High availability
- ✅ Scalable
- ✅ Automatic failover

**Cost:** ~$15-50/month for small instances

---

### 3.2 Heroku Postgres

```bash
# Install Heroku CLI
brew install heroku/brew/heroku

# Login
heroku login

# Create Heroku app
heroku create medical-app-backend

# Add PostgreSQL addon
heroku addons:create heroku-postgresql:hobby-dev

# Get database URL
heroku config:get DATABASE_URL

# Update local .env
DATABASE_URL=postgres://user:password@host.herokuapp.com:5432/dbname
```

**Advantages:**
- ✅ Easy setup
- ✅ Free tier available
- ✅ Automatic backups
- ✅ SSL enabled

**Cost:** Free (10,000 rows), $9/month (10M rows)

---

### 3.3 Azure Database for PostgreSQL

```bash
# Create via Azure Portal or CLI
az postgres server create \
  --resource-group medical-app-rg \
  --name medical-app-db \
  --location eastus \
  --admin-user medical_admin \
  --admin-password YourPassword123! \
  --sku-name B_Gen5_1

# Get connection string
# Update backend/.env
DATABASE_URL=postgresql://medical_admin@medical-app-db:YourPassword123!@medical-app-db.postgres.database.azure.com:5432/medical_app?sslmode=require
```

---

### 3.4 Google Cloud SQL

```bash
# Create Cloud SQL instance via Google Cloud Console
# Connection name: project-id:region:instance-name

# Update backend/.env
DATABASE_URL=postgresql://user:password@/medical_app?host=/cloudsql/project-id:region:instance-name
```

---

## 🔐 Security Best Practices

### 1. Use Environment Variables (Never Hardcode)

```bash
# ❌ Bad - hardcoded in config.py
SQLALCHEMY_DATABASE_URI = 'postgresql://user:password@host:5432/db'

# ✅ Good - use environment variable
SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL')
```

### 2. Strong Password

```bash
# Generate secure password
openssl rand -base64 32

# Use in DATABASE_URL
DATABASE_URL=postgresql://user:Xy9$mK2#vL8qR@host:5432/medical_app
```

### 3. SSL/TLS Encryption

```python
# For production, enforce SSL
DATABASE_URL=postgresql://user:password@host:5432/medical_app?sslmode=require
```

### 4. Firewall Rules

```bash
# Only allow specific IPs to access database
# Configure in PostgreSQL pg_hba.conf or cloud console
```

### 5. Regular Backups

```bash
# Automated backup script
pg_dump -h localhost -U medical_app_user medical_app > backup_$(date +%Y%m%d).sql

# Restore from backup
psql -h localhost -U medical_app_user medical_app < backup_20250124.sql
```

---

## 📊 Comparison Table

| Feature | SQLite (Local) | PostgreSQL (Local Server) | Cloud Database |
|---------|---------------|---------------------------|----------------|
| **Shared Access** | ❌ No | ✅ Yes | ✅ Yes |
| **Concurrent Users** | Limited | High (100s) | Very High (1000s) |
| **Internet Access** | ❌ No | ⚠️ Needs setup | ✅ Built-in |
| **Scalability** | Low | Medium-High | Very High |
| **Backup** | Manual | Manual/Automated | Automated |
| **Cost** | Free | Free (self-hosted) | $0-$50+/month |
| **Maintenance** | None | Medium | Low (managed) |
| **Performance** | Good (local) | Very Good | Good (network latency) |
| **Setup Complexity** | Easy | Medium | Easy-Medium |

---

## 🔄 Migration Steps Summary

### Quick Migration Checklist:

1. ✅ **Install PostgreSQL** on server
2. ✅ **Create database** and user
3. ✅ **Install psycopg2** in backend
4. ✅ **Update DATABASE_URL** in .env
5. ✅ **Run migrations** (flask db upgrade)
6. ✅ **Test connection** from all computers
7. ✅ **Configure firewall** (if remote)
8. ✅ **Setup backups** (automated)
9. ✅ **Enable SSL** (production)
10. ✅ **Monitor performance**

---

## 🧪 Testing the Setup

### Test 1: Connection Test
```python
# backend/test_db_connection.py
from app import create_app
from app import db

app = create_app()

with app.app_context():
    try:
        # Try to connect to database
        db.engine.connect()
        print("✅ Database connection successful!")
        print(f"Database: {db.engine.url}")
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
```

Run:
```bash
python test_db_connection.py
```

### Test 2: Data Sync Test

**On Computer 1:**
```bash
# Create a test patient
curl -X POST http://localhost:5001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@sync.com","password":"pass123","role":"patient"}'
```

**On Computer 2:**
```bash
# Verify patient exists
curl -X POST http://localhost:5001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@sync.com","password":"pass123"}'
```

If login works, data is synced! ✅

---

## 📈 Performance Optimization

### 1. Connection Pooling

```python
# config.py
SQLALCHEMY_ENGINE_OPTIONS = {
    'pool_size': 20,           # Increase for more concurrent connections
    'max_overflow': 50,        # Extra connections when needed
    'pool_recycle': 3600,      # Prevent stale connections
    'pool_pre_ping': True,     # Health check before use
}
```

### 2. Database Indexes

```python
# Add indexes to frequently queried columns
class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), index=True)  # Add index
    phone = db.Column(db.String(15), index=True)  # Add index for search
    email = db.Column(db.String(120), unique=True, index=True)  # Add index
```

### 3. Query Optimization

```python
# Use eager loading to prevent N+1 queries
appointments = Appointment.query\
    .options(db.joinedload(Appointment.doctor))\
    .options(db.joinedload(Appointment.patient))\
    .all()
```

---

## 🔍 Troubleshooting

### Issue 1: "Connection refused"

**Solution:**
```bash
# Check if PostgreSQL is running
sudo systemctl status postgresql

# Start if not running
sudo systemctl start postgresql

# Check port is open
sudo lsof -i :5432
```

### Issue 2: "Password authentication failed"

**Solution:**
```bash
# Reset user password
sudo -u postgres psql
ALTER USER medical_app_user WITH PASSWORD 'new_password';

# Update .env file with new password
```

### Issue 3: "Too many connections"

**Solution:**
```sql
-- Increase max connections in PostgreSQL
ALTER SYSTEM SET max_connections = 200;

-- Restart PostgreSQL
sudo systemctl restart postgresql
```

### Issue 4: "Relation does not exist"

**Solution:**
```bash
# Run migrations
flask db upgrade

# If still fails, recreate migrations
rm -rf migrations/
flask db init
flask db migrate -m "Initial migration"
flask db upgrade
```

---

## 💡 Best Practices

1. **Always use environment variables** for connection strings
2. **Enable SSL** in production
3. **Setup automated backups** (daily recommended)
4. **Monitor connection pool** usage
5. **Use read replicas** for high traffic
6. **Implement connection retry logic**
7. **Log database queries** for debugging
8. **Regular security updates** for PostgreSQL
9. **Use prepared statements** (SQLAlchemy does this)
10. **Monitor slow queries** and optimize

---

## 📚 Additional Resources

- [PostgreSQL Official Documentation](https://www.postgresql.org/docs/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [Flask-SQLAlchemy Documentation](https://flask-sqlalchemy.palletsprojects.com/)
- [PostgreSQL Performance Tuning](https://wiki.postgresql.org/wiki/Performance_Optimization)
- [Database Security Best Practices](https://www.postgresql.org/docs/current/security.html)

---

## ✅ Summary

**To centralize your database:**

1. **Install PostgreSQL** on a central server
2. **Create database** and user with proper permissions
3. **Update backend configuration** to use PostgreSQL
4. **Run migrations** to create tables
5. **Configure network access** if needed
6. **Update all application instances** to connect to central database
7. **Test thoroughly** before production deployment

**Result:** All your application data will be stored in one centralized location, accessible from any computer with proper credentials!

**Recommended Setup:**
- **Development:** Local PostgreSQL
- **Production:** Cloud-hosted (AWS RDS, Heroku, Azure)
- **Enterprise:** Self-hosted PostgreSQL cluster with replication

This ensures data consistency, enables multi-user access, and provides a foundation for scaling your application!
