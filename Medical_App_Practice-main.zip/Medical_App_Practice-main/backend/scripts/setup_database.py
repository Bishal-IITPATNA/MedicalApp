"""
Database Setup Script for Medical App

This script will:
1. Create all database tables
2. Create an admin user (optional)
3. Create test users for all roles (optional)

Usage:
    python setup_database.py              # Create tables only
    python setup_database.py --admin      # Create tables + admin user
    python setup_database.py --with-test-data  # Create tables + test users
    python setup_database.py --all        # Create everything
"""

import sys
from app import create_app, db
from app.models.user import User, Patient, Doctor, Nurse, MedicalStore, LabStore, Admin

def create_tables():
    """Create all database tables"""
    print('Creating database tables...')
    db.create_all()
    print('✅ All tables created successfully!')
    print()

def create_admin_user():
    """Create default admin user"""
    print('Creating admin user...')
    
    # Check if admin already exists
    admin_user = User.query.filter_by(email='admin@medical.com').first()
    if admin_user:
        print('⚠️  Admin user already exists!')
        return
    
    # Create admin user
    admin_user = User(email='admin@medical.com', role='admin')
    admin_user.set_password('admin123')
    db.session.add(admin_user)
    db.session.flush()
    
    # Create admin profile
    admin_profile = Admin(
        user_id=admin_user.id,
        name='System Administrator',
        phone='1234567890',
        designation='Super Admin'
    )
    db.session.add(admin_profile)
    db.session.commit()
    
    print('✅ Admin user created!')
    print('   Email: admin@medical.com')
    print('   Password: admin123')
    print()

def create_test_users():
    """Create test users for all roles"""
    print('Creating test users...')
    
    test_accounts = []
    
    # Test Patient
    if not User.query.filter_by(email='patient@test.com').first():
        patient_user = User(email='patient@test.com', role='patient')
        patient_user.set_password('password123')
        db.session.add(patient_user)
        db.session.flush()
        
        patient = Patient(
            user_id=patient_user.id,
            name='John Doe',
            phone='9876543210',
            address='123 Test Street',
            city='Mumbai',
            state='Maharashtra',
            pincode='400001'
        )
        db.session.add(patient)
        test_accounts.append('patient@test.com / password123 (Patient)')
    
    # Test Doctor
    if not User.query.filter_by(email='doctor@test.com').first():
        doctor_user = User(email='doctor@test.com', role='doctor')
        doctor_user.set_password('password123')
        db.session.add(doctor_user)
        db.session.flush()
        
        doctor = Doctor(
            user_id=doctor_user.id,
            name='Dr. Sarah Smith',
            phone='9876543211',
            specialty='General Physician',
            qualification='MBBS, MD',
            consultation_fee=500.0,
            city='Mumbai',
            state='Maharashtra'
        )
        db.session.add(doctor)
        test_accounts.append('doctor@test.com / password123 (Doctor)')
    
    # Test Nurse
    if not User.query.filter_by(email='nurse@test.com').first():
        nurse_user = User(email='nurse@test.com', role='nurse')
        nurse_user.set_password('password123')
        db.session.add(nurse_user)
        db.session.flush()
        
        nurse = Nurse(
            user_id=nurse_user.id,
            name='Nurse Mary',
            phone='9876543212',
            specialty='General',
            qualification='BSc Nursing',
            city='Mumbai',
            state='Maharashtra'
        )
        db.session.add(nurse)
        test_accounts.append('nurse@test.com / password123 (Nurse)')
    
    # Test Medical Store
    if not User.query.filter_by(email='medstore@test.com').first():
        store_user = User(email='medstore@test.com', role='medical_store')
        store_user.set_password('password123')
        db.session.add(store_user)
        db.session.flush()
        
        med_store = MedicalStore(
            user_id=store_user.id,
            name='ABC Medical Store',
            phone='9876543213',
            license_number='MED12345',
            city='Mumbai',
            state='Maharashtra'
        )
        db.session.add(med_store)
        test_accounts.append('medstore@test.com / password123 (Medical Store)')
    
    # Test Lab Store
    if not User.query.filter_by(email='labstore@test.com').first():
        lab_user = User(email='labstore@test.com', role='lab_store')
        lab_user.set_password('password123')
        db.session.add(lab_user)
        db.session.flush()
        
        lab_store = LabStore(
            user_id=lab_user.id,
            name='XYZ Diagnostic Lab',
            phone='9876543214',
            license_number='LAB12345',
            city='Mumbai',
            state='Maharashtra'
        )
        db.session.add(lab_store)
        test_accounts.append('labstore@test.com / password123 (Lab Store)')
    
    db.session.commit()
    
    if test_accounts:
        print('✅ Test users created:')
        for account in test_accounts:
            print(f'   • {account}')
        print()
    else:
        print('⚠️  All test users already exist!')
        print()

def main():
    """Main setup function"""
    app = create_app()
    
    with app.app_context():
        # Parse command line arguments
        args = sys.argv[1:]
        
        print('='*60)
        print('Medical App - Database Setup')
        print('='*60)
        print()
        
        # Always create tables
        create_tables()
        
        # Check for flags
        if '--admin' in args or '--all' in args:
            create_admin_user()
        
        if '--with-test-data' in args or '--all' in args:
            create_test_users()
        
        print('='*60)
        print('Database setup completed!')
        print('='*60)
        print()
        
        if not any(flag in args for flag in ['--admin', '--with-test-data', '--all']):
            print('💡 Tip: Run with flags to create users:')
            print('   python setup_database.py --admin          # Create admin user')
            print('   python setup_database.py --with-test-data # Create test users')
            print('   python setup_database.py --all            # Create everything')
            print()

if __name__ == '__main__':
    main()
