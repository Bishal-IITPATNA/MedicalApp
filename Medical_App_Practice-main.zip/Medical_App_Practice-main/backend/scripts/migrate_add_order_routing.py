"""
Migration script to add order routing fields to medicine_orders table
"""
import sqlite3
import os

# Get the database path
db_path = os.path.join(os.path.dirname(__file__), 'instance', 'medical_app.db')

print(f"Migrating database: {db_path}")

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Check if columns already exist
    cursor.execute("PRAGMA table_info(medicine_orders)")
    columns = [row[1] for row in cursor.fetchall()]
    
    migrations_needed = []
    
    if 'current_store_id' not in columns:
        migrations_needed.append("ALTER TABLE medicine_orders ADD COLUMN current_store_id INTEGER")
        
    if 'offered_to_stores' not in columns:
        migrations_needed.append("ALTER TABLE medicine_orders ADD COLUMN offered_to_stores TEXT")
        
    if 'current_offer_time' not in columns:
        migrations_needed.append("ALTER TABLE medicine_orders ADD COLUMN current_offer_time DATETIME")
        
    if 'timeout_minutes' not in columns:
        migrations_needed.append("ALTER TABLE medicine_orders ADD COLUMN timeout_minutes INTEGER DEFAULT 5")
    
    # Check medicine_order_items table
    cursor.execute("PRAGMA table_info(medicine_order_items)")
    item_columns = [row[1] for row in cursor.fetchall()]
    
    if 'medicine_name' not in item_columns:
        migrations_needed.append("ALTER TABLE medicine_order_items ADD COLUMN medicine_name VARCHAR(200)")
    
    # Execute migrations
    if migrations_needed:
        print(f"\nApplying {len(migrations_needed)} migrations:")
        for migration in migrations_needed:
            print(f"  - {migration}")
            cursor.execute(migration)
        
        conn.commit()
        print("\n✓ Migrations applied successfully!")
    else:
        print("\n✓ Database is already up to date. No migrations needed.")
    
    # Update medicine_id to be nullable if needed
    cursor.execute("PRAGMA table_info(medicine_order_items)")
    for row in cursor.fetchall():
        if row[1] == 'medicine_id':
            print(f"\nNote: medicine_id column exists with notnull={row[3]}")
            if row[3] == 1:  # notnull is 1
                print("Warning: medicine_id is NOT NULL. You may need to recreate the table to make it nullable.")
    
    conn.close()
    print("\nDatabase migration complete!")
    
except Exception as e:
    print(f"Error during migration: {e}")
    import traceback
    traceback.print_exc()
