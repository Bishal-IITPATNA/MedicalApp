"""
Script to create an admin account.
This should only be run manually by authorized personnel.
"""

import sys
import os

# Add parent directory to path to import app modules
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app, db
from app.models.user import User, Admin
from werkzeug.security import generate_password_hash
import getpass

def create_admin():
    """Create a new admin account"""
    app = create_app()
    
    with app.app_context():
        print("=" * 50)
        print("CREATE ADMIN ACCOUNT")
        print("=" * 50)
        print()
        
        # Get admin details
        email = input("Enter admin email: ").strip()
        
        # Validate email
        if not email or '@' not in email:
            print("❌ Invalid email address!")
            return
        
        # Check if email already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            print(f"❌ User with email '{email}' already exists!")
            return
        
        # Get password with confirmation
        while True:
            password = getpass.getpass("Enter password: ")
            password_confirm = getpass.getpass("Confirm password: ")
            
            if len(password) < 6:
                print("❌ Password must be at least 6 characters long!")
                continue
            
            if password != password_confirm:
                print("❌ Passwords do not match!")
                continue
            
            break
        
        # Get admin name
        name = input("Enter admin name: ").strip()
        if not name:
            name = "Admin"
        
        try:
            # Create user account
            user = User(
                email=email,
                password=generate_password_hash(password),
                role='admin',
                is_active=True
            )
            db.session.add(user)
            db.session.flush()  # Get user.id
            
            # Create admin profile
            admin = Admin(
                user_id=user.id,
                name=name,
                department='Administration'
            )
            db.session.add(admin)
            
            # Commit transaction
            db.session.commit()
            
            print()
            print("✅ Admin account created successfully!")
            print(f"   Email: {email}")
            print(f"   Name: {name}")
            print(f"   User ID: {user.id}")
            print(f"   Admin ID: {admin.id}")
            print()
            print("⚠️  Please keep the credentials secure!")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Error creating admin account: {e}")

if __name__ == '__main__':
    create_admin()
